These files should be dropped into the CHARMe plugin in place of the existing files.

The paths given below are relative to the installation directory of the CHARMe plugin.

1. copy jsonoa.types.js to plugin/js/
2. copy target_types.json to plugin/localData/

Please be sure to refresh your browser cache after updating these files - http://www.refreshyourcache.com/en/home/
